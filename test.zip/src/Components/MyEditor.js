import React, { useEffect, useState } from "react";
import './MyEditor.css';

const MyEditor= (props)=>{
    
    return (
        <div class="my-editor">
            <div id="editor">
            </div>
               
        </div>);
}

export default MyEditor;